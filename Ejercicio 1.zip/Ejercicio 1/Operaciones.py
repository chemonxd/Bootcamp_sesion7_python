def suma(fstNumber, scnNumber):
    return fstNumber + scnNumber


def resta(fstNumber, scnNumber):
    return fstNumber - scnNumber


def multiplicacion(fstNumber, scnNumber):
    return fstNumber * scnNumber


def divicion(fstNumber, scnNumber):
    return fstNumber / scnNumber
