import Operaciones


def select_Operations():

    print("seleccione la operación por favor")
    print(" 1.- Suma \n 2.- Resta \n 3.- Multiplicación \n 4.- Divición")
    selection = int(input())

    if 1 <= selection <= 4:
        if selection == 1:
            fstNumber = int(input("ingrese el primer número a sumar \n"))
            scnNumber = int(input("ingrese el segundo número a sumar \n"))
            print(Operaciones.suma(fstNumber, scnNumber))
        elif selection == 2:
            fstNumber = int(input("ingrese el primer número a restar \n"))
            scnNumber = int(input("ingrese el segundo número a restar \n"))
            print(Operaciones.resta(fstNumber, scnNumber))
        elif selection == 3:
            fstNumber = int(input("ingrese el primer número a multiplicar\n"))
            scnNumber = int(input("ingrese el segundo número a multiplicar\n"))
            print(Operaciones.multiplicacion(fstNumber, scnNumber))
        elif selection == 4:
            fstNumber = int(input("ingrese el primer número a dividir\n"))
            scnNumber = int(input("ingrese el segundo número a dividir\n"))
            if fstNumber != 0 and scnNumber != 0:
                print(Operaciones.divicion(fstNumber, scnNumber))
            else:
                print("No se puede dividir entre cero")
    else:
        print("Las opciones sono son del uno al cuatro")


if __name__ == '__main__':
    select_Operations()
