from datetime import datetime
import time
import CalcularHora


def Horario_laboral():
    h_salida = "19:00"
    obj_hs = time.strptime(h_salida, '%H:%M')

    h_entrada = time.strftime("11:00")
    obj_he = time.strptime(h_entrada, '%H:%M')

    h_actual = time.strftime('%H:%M', time.localtime())
    obj_ha = time.strptime(h_actual, '%H:%M')

    CalcularHora.calcular_salida(obj_ha.tm_hour, obj_ha.tm_min,  obj_he.tm_hour, obj_hs.tm_hour)


if __name__ == '__main__':
    Horario_laboral()
