def calcular_salida(h_actual, ha_min, h_entrada,h_salida):
    if h_actual < h_entrada:
        print("Aún no es la hora de entrada")
    elif h_entrada <= h_actual < h_salida:
        horas = h_salida - h_actual
        restmin = 59-ha_min
        print("Aún te faltan: ", horas, ":", restmin, " para salir")
    elif h_actual >= h_salida:
        horas_e = h_actual - h_salida
        print("Ya pasó tu hora de salida, llevas ", horas_e, " horas extra")


    # Para el ejercicio se probí con la hora = 18 y los minutos actuales